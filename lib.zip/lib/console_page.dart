import 'package:flutter/material.dart';

class ConsolePage extends StatefulWidget {
  const ConsolePage({super.key});

  @override
  State<ConsolePage> createState() => _ConsolePageState();
}

class _ConsolePageState extends State<ConsolePage> {
  List<int> motorValues = [0, 0, 0, 0];
  List<String> consoleLogs = [];

  void sendCommand() {
    String command = 's${motorValues[0]},s${motorValues[1]},s${motorValues[2]},s${motorValues[3]}';
    setState(() {
      consoleLogs.add('✅ Sent: $command');
      for (int i = 0; i < motorValues.length; i++) {
        consoleLogs.add('Servo ${i + 1}: ${motorValues[i]}');
      }
    });
  }

  void clearConsole() {
    setState(() {
      consoleLogs.clear();
    });
  }

  void resetMotors() {
    setState(() {
      motorValues = [0, 0, 0, 0];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[50],
      appBar: AppBar(
        backgroundColor: Colors.purple[100],
        title: const Text('Robot Arm Control Panel'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            for (int i = 0; i < motorValues.length; i++) ...[
              Text('Motor ${i + 1}: ${motorValues[i]}'),
              Slider(
                value: motorValues[i].toDouble(),
                min: 0,
                max: 180,
                divisions: 180,
                label: motorValues[i].toString(),
                onChanged: (value) {
                  setState(() {
                    motorValues[i] = value.toInt();
                  });
                },
              ),
            ],
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: resetMotors,
                  child: const Text('Reset'),
                ),
                ElevatedButton(
                  onPressed: sendCommand,
                  child: const Text('Run'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                const Text('Serial Console:', style: TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                TextButton(onPressed: clearConsole, child: const Text('Clear'))
              ],
            ),
            Expanded(
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ListView.builder(
                  itemCount: consoleLogs.length,
                  itemBuilder: (context, index) => Text(consoleLogs[index]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}