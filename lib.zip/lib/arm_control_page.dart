import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ArmControlPage extends StatefulWidget {
  @override
  _ArmControlPageState createState() => _ArmControlPageState();
}

class _ArmControlPageState extends State<ArmControlPage> {
  List<int> motorValues = [0, 0, 0, 0];
  List<Map<String, dynamic>> savedPoses = [];

  @override
  void initState() {
    super.initState();
    fetchSavedPoses();
  }

  Future<void> fetchSavedPoses() async {
    final response =
    await http.get(Uri.parse('http://localhost/robot_api/get_run_pose.php'));
    if (response.statusCode == 200) {
      List data = json.decode(response.body);
      setState(() {
        savedPoses = List<Map<String, dynamic>>.from(data);
      });
    }
  }

  Future<void> savePose() async {
    final response = await http.post(
      Uri.parse('http://localhost/robot_api/update_status.php'),
      body: {
        'motor1': motorValues[0].toString(),
        'motor2': motorValues[1].toString(),
        'motor3': motorValues[2].toString(),
        'motor4': motorValues[3].toString(),
      },
    );
    if (response.statusCode == 200) {
      fetchSavedPoses();
    }
  }

  Future<void> deletePose(String id) async {
    final response = await http.post(
      Uri.parse('http://localhost/robot_api/delete_pose.php'),
      body: {'id': id},
    );
    if (response.statusCode == 200) {
      fetchSavedPoses();
    }
  }

  Widget buildSlider(String label, int index) {
    return Column(
      children: [
        Text(label),
        Slider(
          value: motorValues[index].toDouble(),
          min: 0,
          max: 180,
          divisions: 180,
          label: motorValues[index].toString(),
          onChanged: (double value) {
            setState(() {
              motorValues[index] = value.toInt();
            });
          },
        ),
      ],
    );
  }

  Widget buildSavedPosesList() {
    return Column(
      children: savedPoses.map((pose) {
        String id = pose['id'].toString();
        String poseText =
            'M1:${pose['motor1']} M2:${pose['motor2']} M3:${pose['motor3']} M4:${pose['motor4']}';

        return Card(
          child: ListTile(
            title: Text(poseText),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.play_arrow),
                  onPressed: () {
                    // TODO: تنفيذ الوضعية لاحقًا
                  },
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () => deletePose(id),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Robot Arm Control')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            buildSlider('Motor 1', 0),
            buildSlider('Motor 2', 1),
            buildSlider('Motor 3', 2),
            buildSlider('Motor 4', 3),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      motorValues = [0, 0, 0, 0];
                    });
                  },
                  child: Text('Reset'),
                ),
                ElevatedButton(
                  onPressed: savePose,
                  child: Text('Save Pose'),
                ),
                ElevatedButton(
                  onPressed: () async {
                    final response = await http.post(
                      Uri.parse('http://localhost/robot_api/run_pose.php'),
                      body: {
                        'motor1': motorValues[0].toString(),
                        'motor2': motorValues[1].toString(),
                        'motor3': motorValues[2].toString(),
                        'motor4': motorValues[3].toString(),
                      },
                    );
                    if (response.statusCode == 200) {
                      print('Pose sent successfully!');
                    }
                  },
                  child: Text('Run'),
                ),
              ],
            ),
            SizedBox(height: 20),
            buildSavedPosesList(),
          ],
        ),
      ),
    );
  }
}