import 'package:flutter/material.dart';

class UsbPage extends StatefulWidget {
  const UsbPage({super.key});

  @override
  State<UsbPage> createState() => _UsbPageState();
}

class _UsbPageState extends State<UsbPage> {
  List<String> usbDevices = [
    'USB Type-C Digital AV Adapter\nVID: 13327 / PID: 0',
    'USB Single Serial\nVID: 6790 / PID: 21972',
  ];

  String? connectedDevice;
  List<String> consoleMessages = [
    '✅ Connected to USB Single Serial',
    'Sent: s190,s290,s390,s490 (BaudRate: 115200)',
    'Servo 1: 90',
    'Servo 2: 90',
    'Servo 3: 90',
    'Servo 4: 90',
  ];

  void connectToDevice(String device) {
    setState(() {
      connectedDevice = device;
    });
  }

  void clearConsole() {
    setState(() {
      consoleMessages.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[50],
      appBar: AppBar(
        backgroundColor: Colors.purple[100],
        centerTitle: true,
        title: const Text("USB Serial Interface"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text("الأجهزة", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            for (var device in usbDevices)
              Container(
                margin: const EdgeInsets.only(bottom: 10),
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => connectToDevice(device),
                  child: Text("اتصال\n$device", textAlign: TextAlign.center),
                ),
              ),
            ElevatedButton(
              onPressed: () {}, // تختارين الجهاز النهائي هنا
              child: const Text("اختيار الاتصال"),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                const Icon(Icons.check_box, color: Colors.green),
                const SizedBox(width: 8),
                const Text("Serial Console:", style: TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                TextButton(
                  onPressed: clearConsole,
                  child: const Text("Clear"),
                ),
              ],
            ),
            Expanded(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade400),
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.white,
                ),
                child: ListView(
                  children: consoleMessages.map((msg) => Text(msg)).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}