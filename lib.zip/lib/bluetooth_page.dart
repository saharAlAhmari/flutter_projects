import 'package:flutter/material.dart';

class BluetoothPage extends StatefulWidget {
  const BluetoothPage({super.key});

  @override
  State<BluetoothPage> createState() => _BluetoothPageState();
}

class _BluetoothPageState extends State<BluetoothPage> {
  bool isConnected = false;
  List<String> devices = [
    'ESP_Bluetooth\n88:13:8F:23:A4:A6',
    '30:99:24:54:6F:30',
    'M5C_F4:9D:8A:45:93:5B\nF4:9D:8A:45:93:5C',
    'M5C_E8:EC:C9:83:AB:BF\nE8:EC:C9:83:AC:C0',
    '3A:EE:4D:36:A8:06',
    'AA:B1:3B:08:60:08',
    '6D:AE:B7:88:1A:0A',
  ];
  int? selectedDevice;

  void connectToDevice(int index) {
    setState(() {
      selectedDevice = index;
      isConnected = true;
    });
  }

  void disconnectDevice() {
    setState(() {
      isConnected = false;
      selectedDevice = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[50],
      appBar: AppBar(
        title: const Text('Bluetooth Interface'),
        backgroundColor: Colors.purple[100],
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            if (!isConnected) ...[
              ElevatedButton(
                onPressed: () {},
                child: const Text('إظهار قائمة الأجهزة'),
              ),
              const SizedBox(height: 10),
              ...devices.asMap().entries.map((entry) {
                final index = entry.key;
                final device = entry.value;
                return ListTile(
                  title: Text(device),
                  trailing: ElevatedButton(
                    onPressed: () => connectToDevice(index),
                    child: const Text('اتصال'),
                  ),
                );
              }),
            ] else ...[
              const Text('انقر على ESP_Bluetooth من القائمة التالية'),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: disconnectDevice,
                child: const Text('عرض قائمة الأجهزة'),
              ),
              const SizedBox(height: 20),
              const Text(
                'تم الاتصال بنجاح',
                style: TextStyle(
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}