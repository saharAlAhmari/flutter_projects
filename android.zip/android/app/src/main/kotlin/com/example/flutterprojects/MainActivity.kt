package com.example.flutterprojects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
